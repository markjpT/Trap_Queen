- A new `getprioritisedtransactions` RPC has been added. It returns a map of all fee deltas created by the
  user with prioritisetransaction, indexed by txid. The map also indicates whether each transaction is
  present in the mempool.
